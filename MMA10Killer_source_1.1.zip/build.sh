#!/bin/sh
# Build MMA10Killer.asi (32-bit Windows DLL) with clang + lld on Linux.
set -e
cd "$(dirname "$0")"
llvm-dlltool -m i386 -k -d build/kernel32.def -l build/kernel32.lib
llvm-rc /fo build/version.res build/version.rc
clang --target=i686-pc-windows-msvc -O2 -ffreestanding -fno-builtin -fno-stack-protector \
      -fno-asynchronous-unwind-tables -fno-unwind-tables -Wall -Wextra \
      -c src/mma10killer.c -o build/mma10killer.obj
lld-link /dll /nodefaultlib /entry:DllMain@12 /subsystem:windows,5.01 /machine:x86 \
         /filealign:512 /opt:ref /opt:icf /dynamicbase /nxcompat /map:build/MMA10Killer.map /out:MMA10Killer.asi \
         build/mma10killer.obj build/kernel32.lib build/version.res
python3 -I tools/pe_checksum.py MMA10Killer.asi
ls -l MMA10Killer.asi
