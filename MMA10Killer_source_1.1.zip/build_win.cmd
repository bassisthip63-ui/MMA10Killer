@echo off
rem Build MMA10Killer.asi on Windows with LLVM (winget install LLVM.LLVM). Keep this folder on a short path.
set LLVM=C:\Program Files\LLVM\bin
cd /d "%~dp0" || exit /b 10
"%LLVM%\llvm-dlltool.exe" -m i386 -k -d build\kernel32.def -l build\kernel32.lib || exit /b 11
"%LLVM%\llvm-rc.exe" /fo build\version.res build\version.rc || exit /b 14
"%LLVM%\clang.exe" --target=i686-pc-windows-msvc -O2 -ffreestanding -fno-builtin -fno-stack-protector -fno-asynchronous-unwind-tables -fno-unwind-tables -Wall -Wextra -Wno-unused-function -c src\mma10killer.c -o build\mma10killer.obj || exit /b 12
"%LLVM%\lld-link.exe" /dll /nodefaultlib /entry:DllMain@12 /subsystem:windows,5.01 /machine:x86 /filealign:512 /opt:ref /opt:icf /dynamicbase /nxcompat /map:build\MMA10Killer.map /out:MMA10Killer.asi build\mma10killer.obj build\kernel32.lib build\version.res || exit /b 13
python tools\pe_checksum.py MMA10Killer.asi || echo note: python not found, PE checksum left at 0
dir MMA10Killer.asi
