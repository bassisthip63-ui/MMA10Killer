/*
 * MMA10Killer.asi  -  stops GTA IV 1.2.0.59 showing the "MMA10" error box, or hanging, while the game is closing.
 *
 * Copyright (c) 2026 bassisthip63-ui. MIT License (see LICENSE).
 *
 * What the game does (GTAIV.exe 1.2.0.59, addresses as in the exe file, preferred base 0x400000):
 *   - All game memory goes through one "multi allocator" object at 0x1BB68D8 (vtable 0xFC9944). It keeps up to 8
 *     sub-allocators in an array at +0x04, with their count at +0x24 (the game registers 4).
 *   - Its Free (0x401E90) asks each sub-allocator "is this pointer yours?" (vtable +0x48) and hands the pointer to the
 *     one that says yes (vtable +0x0C). When none says yes it calls the fatal error routine with the code "MMA10".
 *   - Some mod setups leave a pointer behind that no sub-allocator recognises. The game only frees it while shutting
 *     down, so the error box pops up on exit even though nothing went wrong while playing.
 *
 * What this plugin does:
 *   - Nothing at all while you play. A real MMA10 during play means memory really is damaged, and you should see it.
 *   - When the game leaves its main loop to shut down (the call to the shutdown routine 0x5C1710 at 0x59D857), it adds
 *     one extra sub-allocator to the END of that array. The game's own sub-allocators are still asked first, so every
 *     normal free goes exactly where it always did. Only a pointer that NONE of them owns reaches the extra one, which
 *     says "mine", does nothing with it, and writes a line to MMA10Killer.log. Nothing is freed twice, nothing is
 *     written anywhere, and the process is about to end anyway.
 *   - It patches one call instruction (5 bytes) in the game's code, outside the part of the exe that is encrypted on
 *     disk, after checking the exe build and the exact bytes. On any other build or if anything looks different it does
 *     nothing and says so in the log.
 *
 *   - Also only once the game is closing: if the shutdown code itself crashes (for example on a stale pointer left by a
 *     mod - seen in phMaterialMgrGta's table), Windows would otherwise spend a long time on error reporting before the
 *     process goes away ("hangs on exit"). An unhandled-exception filter, installed at that moment and not before,
 *     writes one line to the log and ends the process straight away instead. Crashes DURING play are untouched.
 *
 * No threads, no network, no other files touched, no CRT. Build: build.sh (Linux) or build_win.cmd (Windows, LLVM).
 */

typedef unsigned int u32;
typedef int i32;
typedef unsigned short u16;
typedef unsigned char u8;
typedef void *HANDLE;
typedef int BOOL;
typedef u32 DWORD;

#define IMP __declspec(dllimport)
IMP HANDLE __stdcall GetModuleHandleA(const char *);
IMP DWORD  __stdcall GetModuleFileNameA(HANDLE, char *, DWORD);
IMP BOOL   __stdcall VirtualProtect(void *, u32, DWORD, DWORD *);
IMP BOOL   __stdcall FlushInstructionCache(HANDLE, const void *, u32);
IMP HANDLE __stdcall GetCurrentProcess(void);
IMP HANDLE __stdcall CreateFileA(const char *, DWORD, DWORD, void *, DWORD, DWORD, HANDLE);
IMP BOOL   __stdcall WriteFile(HANDLE, const void *, DWORD, DWORD *, void *);
IMP BOOL   __stdcall CloseHandle(HANDLE);
IMP BOOL   __stdcall DisableThreadLibraryCalls(HANDLE);
IMP DWORD  __stdcall SetFilePointer(HANDLE, i32, i32 *, DWORD);
IMP void * __stdcall SetUnhandledExceptionFilter(void *);
IMP BOOL   __stdcall TerminateProcess(HANDLE, u32);
IMP HANDLE __stdcall CreateThread(void *, u32, void *, void *, DWORD, DWORD *);
IMP void   __stdcall Sleep(DWORD);

#define INVALID_HANDLE ((HANDLE)(i32)-1)

/* ---- GTAIV.exe 1.2.0.59 ---- */
#define PREF_BASE      0x00400000u
#define EXE_TIMESTAMP  0x63D3E735u
#define EXE_IMAGESIZE  0x01BE6400u
#define VA_CALLSITE    0x0059D857u   /* E8 rel32: call 0x5C1710, right after the main loop ends */
#define VA_SHUTDOWN    0x005C1710u
#define VA_MULTI       0x01BB68D8u   /* the multi allocator object */
#define VA_MULTI_VTBL  0x00FC9944u
#define MULTI_ARRAY    0x04u
#define MULTI_COUNT    0x24u
#define MULTI_CAPACITY 8

#define VERSION_TEXT "MMA10Killer 1.2"
#define MAX_LOGGED     20
#define MAX_IGNORED    500     /* more than this: the shutdown code is going round in circles over broken data */
#define WATCHDOG_MS    20000   /* still not closed after this long: it is stuck */

static u32 g_delta;                       /* where the exe really loaded, minus 0x400000 */
static char g_log_path[280];
static volatile long g_armed;             /* 1 once the extra sub-allocator is in place */
static volatile long g_ignored;           /* how many exit-time frees it has taken */
u32 g_shutdown_target;                    /* used by the asm stub below */

static u32 rd32(const void *p) { const u8 *b = (const u8 *)p; return b[0] | (b[1] << 8) | (b[2] << 16) | ((u32)b[3] << 24); }

/* ---- log ---- */
static void log_write(const char *s, int create) {
    DWORD n = 0, len = 0;
    HANDLE h;
    if (!g_log_path[0]) return;
    while (s[len]) len++;
    h = CreateFileA(g_log_path, 0x40000000u /* GENERIC_WRITE */, 1u /* share read */, 0,
                    create ? 2u /* CREATE_ALWAYS */ : 4u /* OPEN_ALWAYS */, 0x80u, 0);
    if (h == INVALID_HANDLE) return;
    SetFilePointer(h, 0, 0, 2u /* FILE_END */);
    WriteFile(h, s, len, &n, 0);
    CloseHandle(h);
}
static char *put_s(char *o, const char *s) { while (*s) *o++ = *s++; return o; }
static char *put_hex(char *o, u32 v) {
    int i;
    *o++ = '0'; *o++ = 'x';
    for (i = 28; i >= 0; i -= 4) *o++ = "0123456789ABCDEF"[(v >> i) & 15];
    return o;
}
static char *put_dec(char *o, u32 v) {
    char t[12]; int n = 0;
    do { t[n++] = (char)('0' + v % 10); v /= 10; } while (v);
    while (n) *o++ = t[--n];
    return o;
}

/* ---- the extra sub-allocator (thiscall, matching the game's sub-allocator vtable) ----
 * Only the slots the multi allocator calls on EVERY sub-allocator are reachable; the rest are filled with a harmless
 * one-argument "return 0". Slots by byte offset:
 *   +0x0C Free(p)       -> do nothing, log it            +0x48 IsMine(p)  -> yes
 *   +0x18 / +0x4C / +0x60 / +0x64 (p)  -> 0             +0x1C (x)       -> 0 (summed by the caller)
 *   +0x20 ()  -> 0                                       +0x44 ()        -> nothing
 */

static void write_total(void) {
    char b[160], *o = b;
    if (!g_ignored) return;
    o = put_s(o, "closed: "); o = put_dec(o, (u32)g_ignored);
    o = put_s(o, g_ignored == 1 ? " exit-time MMA10 was" : " exit-time MMA10s were");
    o = put_s(o, " prevented this session\r\n"); *o = 0; log_write(b, 0);
}
static volatile long g_ending;
static void end_now(const char *why) {
    if (__sync_lock_test_and_set(&g_ending, 1)) { for (;;) Sleep(1000); }   /* someone else is already ending it */
    log_write(why, 0);
    write_total();
    TerminateProcess(GetCurrentProcess(), 0);
}

#define THISCALL __attribute__((thiscall))
static THISCALL u32 fa_ret0_arg(void *self, u32 a) { (void)self; (void)a; return 0; }
static THISCALL u32 fa_ret0_noarg(void *self) { (void)self; return 0; }
static THISCALL u32 fa_is_mine(void *self, u32 p) { (void)self; (void)p; return 1; }
static THISCALL void fa_free(void *self, u32 p) {
    long n;
    (void)self;
    n = __sync_add_and_fetch(&g_ignored, 1);
    if (n <= MAX_LOGGED) {
        char b[160], *o = b;
        o = put_s(o, "exit: the game tried to free "); o = put_hex(o, p);
        o = put_s(o, ", which none of its heaps owns (this is what showed MMA10). Ignored.\r\n");
        *o = 0; log_write(b, 0);
    } else if (n == MAX_LOGGED + 1) {
        log_write("exit: more of the same, not logged one by one (the total is written when the game has closed)\r\n", 0);
    } else if (n == MAX_IGNORED) {
        end_now("closing: the game's shutdown code is going round in circles over broken data (500 bad frees) - this is "
                "what locks the game up on exit. Ending the process now.\r\n");
    }
}

static void *g_fake_vtbl[32];
static struct { void **vtbl; } g_fake = { g_fake_vtbl };

static void fake_init(void) {
    int i;
    for (i = 0; i < 32; i++) g_fake_vtbl[i] = (void *)fa_ret0_arg;
    g_fake_vtbl[0x0C / 4] = (void *)fa_free;
    g_fake_vtbl[0x20 / 4] = (void *)fa_ret0_noarg;
    g_fake_vtbl[0x44 / 4] = (void *)fa_ret0_noarg;
    g_fake_vtbl[0x48 / 4] = (void *)fa_is_mine;
}

/* ---- a crash inside the shutdown code itself ----
 * Installed only once the game is closing. Only exceptions that nothing else handled get here (first-chance ones that
 * the game or a mod deals with never do). The game was going to end anyway; ending it now skips the long wait while
 * Windows collects crash data. */
typedef struct { u32 code, flags; void *rec; u32 address, nparams, info[15]; } EXC_RECORD;
typedef struct { EXC_RECORD *rec; void *ctx; } EXC_POINTERS;
static __stdcall i32 exit_crash_filter(EXC_POINTERS *ep) {
    char b[220], *o = b;
    u32 code = ep && ep->rec ? ep->rec->code : 0, at = ep && ep->rec ? ep->rec->address : 0;
    o = put_s(o, "closing: the game's own shutdown code crashed (code "); o = put_hex(o, code);
    o = put_s(o, " at "); o = put_hex(o, at);
    if (at >= (u32)GetModuleHandleA(0) && at < (u32)GetModuleHandleA(0) + EXE_IMAGESIZE) {
        o = put_s(o, " = exe address "); o = put_hex(o, at - g_delta);
    }
    if (ep && ep->rec && code == 0xC0000005u && ep->rec->nparams >= 2) {
        o = put_s(o, ep->rec->info[0] ? ", writing " : ", reading "); o = put_hex(o, ep->rec->info[1]);
    }
    o = put_s(o, "). Ending the process now instead of waiting on Windows error reporting.\r\n"); *o = 0;
    end_now(b);
    return 1;                             /* EXCEPTION_EXECUTE_HANDLER (not reached) */
}

/* ---- a shutdown that never finishes ----
 * Started when the game begins closing. A normal exit is over in a few seconds and takes this thread with it. */
static __stdcall DWORD watchdog(void *arg) {
    (void)arg;
    Sleep(WATCHDOG_MS);
    end_now("closing: the game was still not closed 20 seconds after it started shutting down (stuck). Ending the process now.\r\n");
    return 0;
}

/* ---- the moment the game starts shutting down ---- */
__attribute__((used)) void mma10killer_on_shutdown(void) {
    u8 *multi = (u8 *)(VA_MULTI + g_delta);
    i32 n;
    char b[200], *o = b;
    if (__sync_lock_test_and_set(&g_armed, 1)) return;
    SetUnhandledExceptionFilter((void *)exit_crash_filter);   /* only from here on, never during play */
    {
        HANDLE t = CreateThread(0, 0, (void *)watchdog, 0, 0, 0);
        if (t) CloseHandle(t);
    }
    if (rd32(multi) != VA_MULTI_VTBL + g_delta) {
        log_write("shutdown: the game's allocator does not look as expected - left alone\r\n", 0);
        return;
    }
    n = (i32)rd32(multi + MULTI_COUNT);
    if (n < 1 || n >= MULTI_CAPACITY) {
        o = put_s(o, "shutdown: the game's allocator has "); o = put_dec(o, (u32)n);
        o = put_s(o, " heaps, no free slot - left alone\r\n"); *o = 0; log_write(b, 0);
        return;
    }
    *(void **)(multi + MULTI_ARRAY + 4 * n) = &g_fake;          /* slot first ...         */
    __atomic_store_n((i32 *)(multi + MULTI_COUNT), n + 1, __ATOMIC_SEQ_CST);  /* ... then make it visible */
    o = put_s(o, "shutdown: the game is closing - exit-time safety net in place (heap slot ");
    o = put_dec(o, (u32)n); o = put_s(o, ")\r\n"); *o = 0; log_write(b, 0);
}

/* jumped to instead of the game's shutdown routine; keeps every register and flag, then goes on to the real one */
__attribute__((naked)) static void shutdown_stub(void) {
    __asm__ volatile(
        "pushal\n\t"
        "pushfl\n\t"
        "call _mma10killer_on_shutdown\n\t"
        "popfl\n\t"
        "popal\n\t"
        "jmp *_g_shutdown_target\n\t");
}

/* ---- install ---- */
static int install(HANDLE self) {
    const u8 *img = (const u8 *)GetModuleHandleA(0);
    u32 pe, n, k, dot = 0;
    u8 *site;
    DWORD old;
    char b[240], *o;

    n = GetModuleFileNameA(self, g_log_path, 260);
    if (n == 0 || n >= 260) { g_log_path[0] = 0; return 0; }
    for (k = 0; k < n; k++) {
        if (g_log_path[k] == '.') dot = k;
        if (g_log_path[k] == '\\' || g_log_path[k] == '/') dot = 0;
    }
    if (!dot) dot = n;
    o = g_log_path + dot; o = put_s(o, ".log"); *o = 0;
    log_write(VERSION_TEXT " - stops the MMA10 error box and exit hangs, only while GTA IV 1.2.0.59 is closing\r\n", 1);

    g_delta = (u32)img - PREF_BASE;
    if (img[0] != 'M' || img[1] != 'Z') { log_write("cannot read GTAIV.exe header - doing nothing\r\n", 0); return 0; }
    pe = rd32(img + 0x3C);
    if (rd32(img + pe) != 0x00004550u || rd32(img + pe + 8) != EXE_TIMESTAMP || rd32(img + pe + 24 + 56) != EXE_IMAGESIZE) {
        log_write("this is not GTAIV.exe 1.2.0.59 - doing nothing (1.0.8.0 and older do not need this plugin)\r\n", 0);
        return 0;
    }

    site = (u8 *)(VA_CALLSITE + g_delta);
    if (site[0] != 0xE8 || (u32)site + 5 + rd32(site + 1) != VA_SHUTDOWN + g_delta) {
        o = b; o = put_s(o, "the game code at "); o = put_hex(o, VA_CALLSITE);
        o = put_s(o, " is not what this version expects (another mod may have changed it) - doing nothing\r\n");
        *o = 0; log_write(b, 0);
        return 0;
    }
    if (rd32((const void *)(VA_MULTI + g_delta)) != VA_MULTI_VTBL + g_delta && rd32((const void *)(VA_MULTI + g_delta)) != 0) {
        log_write("the game's allocator is not where this version expects - doing nothing\r\n", 0);
        return 0;
    }

    fake_init();
    g_shutdown_target = VA_SHUTDOWN + g_delta;
    if (!VirtualProtect(site, 5, 0x40u /* PAGE_EXECUTE_READWRITE */, &old)) {
        log_write("could not unprotect the game code - doing nothing\r\n", 0);
        return 0;
    }
    {
        u32 rel = (u32)shutdown_stub - ((u32)site + 5);
        site[1] = (u8)rel; site[2] = (u8)(rel >> 8); site[3] = (u8)(rel >> 16); site[4] = (u8)(rel >> 24);
    }
    VirtualProtect(site, 5, old, &old);
    FlushInstructionCache(GetCurrentProcess(), site, 5);

    o = b; o = put_s(o, "GTAIV.exe 1.2.0.59 found (loaded at "); o = put_hex(o, (u32)img);
    o = put_s(o, "). Ready: nothing changes while you play; the safety net goes in when the game starts closing.\r\n");
    *o = 0; log_write(b, 0);
    return 1;
}

BOOL __stdcall DllMain(HANDLE self, DWORD reason, void *reserved) {
    (void)reserved;
    if (reason == 1) {                    /* DLL_PROCESS_ATTACH */
        DisableThreadLibraryCalls(self);
        install(self);
    } else if (reason == 0 && g_armed) {  /* DLL_PROCESS_DETACH: the game has closed */
        write_total();
    }
    return 1;
}
