MMA10Killer 1.2  -  for GTA IV Complete Edition 1.2.0.59
=========================================================

What it fixes
-------------
With some mod setups, GTA IV 1.2.0.59 misbehaves when you quit, even though nothing went wrong while you played:
  - an "MMA10" error box pops up (and the Rockstar launcher may report an error), and/or
  - the game hangs on a black screen for a long time before it finally closes.
MMA10Killer fixes both, and it only acts while the game is closing.

How it works, in short
----------------------
MMA10: when the game frees memory, it asks each of its memory heaps "is this yours?". MMA10 means none of them
said yes. Some mods leave a stale or garbage pointer behind (the logs show values like 0xCDCDCDCD), and the game
only tries to free it while shutting down. The moment the game leaves its main loop to close, MMA10Killer adds one
extra "heap" to the END of that list. The game's own heaps are still asked first, so all normal memory is freed
exactly as before. Only a pointer that none of them owns reaches the extra one, which accepts it and does nothing.

Exit hang: sometimes the game's own shutdown code crashes on such a stale pointer. Windows then spends a long time
collecting crash data before the process goes away. From the moment the game starts closing, MMA10Killer catches a
crash that nothing else handled, notes it in the log, and ends the process right away.

Exit lock-up (new in 1.2): with some setups the shutdown code goes round in circles over the same broken data,
trying to free the same garbage pointers again and again, and the game freezes instead of closing. MMA10Killer
ends the process once it has seen 500 such frees, and as a last resort if the game still has not closed 20 seconds
after it started shutting down.

While you are playing, it does nothing at all. If MMA10 or a crash happens DURING play, you will still see it, and
you should: that means something really is wrong, and hiding it could lead to worse problems later.

Install
-------
Back up your game folder (or at least note what you add) before installing any mod.
Copy MMA10Killer.asi into the folder where your other .asi plugins are (the game folder, or "plugins" if your ASI
loader uses one). An ASI loader is required (Fusion Fix and most mod setups already have one).
To uninstall, delete MMA10Killer.asi (and MMA10Killer.log).

Which game versions
-------------------
GTAIV.exe 1.2.0.59 (Complete Edition) only. On any other version it does nothing and says so in its log.
Downgraded 1.0.8.0 / 1.0.7.0 installs do not need it.

The log
-------
MMA10Killer.log is written next to the plugin each session. A session where it had something to do looks like:
    shutdown: the game is closing - exit-time safety net in place (heap slot 4)
    exit: the game tried to free 0xCDCDCDCD, which none of its heaps owns (this is what showed MMA10). Ignored.
    closing: the game's own shutdown code crashed (...). Ending the process now instead of waiting on Windows error reporting.
or, for an exit lock-up:
    closing: the game's shutdown code is going round in circles over broken data (500 bad frees) ...
    closing: the game was still not closed 20 seconds after it started shutting down (stuck) ...
If you only see the "Ready" and "safety net in place" lines, your setup had nothing to fix that time.

Safety and antivirus
--------------------
- No network access, no files touched except its own log. One small timer thread is started only when the game
  begins closing (the 20-second last resort); nothing runs while you play.
- It changes one 5-byte call instruction in the game's code (after checking the exe version and the exact bytes)
  and, only at exit, one entry in the game's heap list and the process's crash handler.
- Not packed or obfuscated; the full source code is included and can be built with the free LLVM tools
  (build_win.cmd on Windows, build.sh on Linux).
- It is not code-signed (that needs a paid certificate). If a scanner flags it, you can submit it to the scanner's
  vendor as a false positive, or build it yourself from the source.

Credits and license
-------------------
By bassisthip63-ui. MIT License (see LICENSE).
Not affiliated with Rockstar Games or Take-Two Interactive. Use it on your own legally owned copy of the game.
